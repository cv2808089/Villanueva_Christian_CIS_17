#ifndef EMPLOYEE_H
#define EMPLOYEE_H

struct employee
{
    std::string name;
    int hours;
    float rate;
    float gross;
    std::string gwords;
};

#endif /* EMPLOYEE_H */

